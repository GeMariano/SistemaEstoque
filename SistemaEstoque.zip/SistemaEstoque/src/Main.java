import model.Produto;
import service.EstoqueService;

public class Main {

    public static void main(String[] args) {

        EstoqueService estoque = new EstoqueService();

        // Criando produtos
        Produto p1 = new Produto(1, "Notebook", 3500.00, 10);
        Produto p2 = new Produto(2, "Mouse", 80.00, 50);

        // Adicionando produtos
        estoque.adicionarProduto(p1);
        estoque.adicionarProduto(p2);

        System.out.println("\n--- Lista de Produtos ---");
        estoque.listarProdutos();

        // Atualizando quantidade
        System.out.println("\n--- Atualizando Estoque ---");
        Produto produtoBuscado = estoque.buscarProdutoPorId(1);
        if (produtoBuscado != null) {
            produtoBuscado.removerQuantidade(2);
        }

        System.out.println("\n--- Lista Atualizada ---");
        estoque.listarProdutos();

        // Removendo produto
        System.out.println("\n--- Removendo Produto ---");
        estoque.removerProduto(2);

        System.out.println("\n--- Lista Final ---");
        estoque.listarProdutos();
    }
}