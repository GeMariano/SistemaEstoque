package test;

import model.Produto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.platform.console.ConsoleLauncher;

public class EstoqueServiceTest {

    @Test
    public void testAdicionarQuantidade() {
        Produto produto = new Produto(1, "Notebook", 3500.00, 10);
        produto.adicionarQuantidade(5);
        Assertions.assertEquals(15, produto.getQuantidade(), "A quantidade do produto deve ser 15");
        System.out.println("Teste passou!");
    }

    // Método main para rodar manualmente
    public static void main(String[] args) {
        EstoqueServiceTest teste = new EstoqueServiceTest();
        teste.testAdicionarQuantidade();
    }
}