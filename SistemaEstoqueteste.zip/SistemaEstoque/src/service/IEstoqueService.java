package service;

import model.Produto;

public interface IEstoqueService {

    void adicionarProduto(Produto produto);

    void listarProdutos();

    Produto buscarProdutoPorId(int id);

    void removerProduto(int id);
}
